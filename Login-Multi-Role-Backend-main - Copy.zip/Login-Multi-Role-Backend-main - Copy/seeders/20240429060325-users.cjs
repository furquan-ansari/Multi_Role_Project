'use strict';

const argon2 = require('argon2');
const { v4: uuidv4 } = require('uuid'); // Import uuidv4 from uuid package

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    // Generate UUID
    const uuid = uuidv4();

    // Hash the password using Argon2
    const hashedPassword = await argon2.hash('admin');

    await queryInterface.bulkInsert('users', [
      {
        uuid: uuid, // Insert the generated UUID
        name: "admin",
        email: "admin@test.com",
        password: hashedPassword, // Insert the hashed password
        role: "admin",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  // async down(queryInterface, Sequelize) {
  //   await queryInterface.bulkDelete('users', null, {});
  // }

  async down(queryInterface, Sequelize) {
    // Delete the user with email "admin@test.com"
    await queryInterface.sequelize.transaction(async (transaction) => {
      await queryInterface.sequelize.query(
        `DELETE FROM users WHERE email = 'admin@test.com'`,
        { transaction }
      );
    });
  }
};
