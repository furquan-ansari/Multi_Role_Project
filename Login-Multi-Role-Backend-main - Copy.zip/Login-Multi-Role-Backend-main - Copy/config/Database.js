import Sequelize from "sequelize";
const sequelize = new Sequelize("featsystemsdb", "root", "root", {
  host: "localhost",
  dialect: "mysql",
});

sequelize
  .sync()
  .then(() => {
    console.log("All models were synchronized successfully.");
  })
  .catch((err) => {
    console.error("Error synchronizing models:", err);
  });

export default sequelize;
